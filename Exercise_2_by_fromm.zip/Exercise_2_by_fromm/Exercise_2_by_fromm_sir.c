#include<stdio.h>
#include<stdlib.h>


/*********************************************************************
 * Function Definition
 * ******************************************************************/
/*
 *
 */

enum error{

	err_ok,                     //!< function worked as expected, no error
	err_wrong_param,            //!<      caller provided wrong parameters
	err_dummy_user,
	err_no_memory,
};

typedef enum error error_t;
/*********************************************************************
 * Function Declaration
 * ******************************************************************/
/*
 * This Function will ask the user to enter a specific value
 * The value will be returned if it is above the provided min boundary
 * If not the, the user will be asked to reenter the value
 *
 * \para float min : [IN] the minimum boundary of the value
 * return the entered value from the user
 * */

float entervalueabove(float min);

error_t entervalueabovewitherrorcode(float min,  float * const pusevalue);

/*********************************************************************
 * Main
 * ******************************************************************/

//Main program will calculate the material required for an eliptical bridge
int main()
{
	printf("Hello World!");
	// some magin to avoid buffer problem
	setvbuf(stdout, NULL,_IONBF,0);
#if 0
	float a = entervalueabove(0);
	unsigned int N = entervalueabove(2);
	printf("The user entered %f for a",a);
		printf("The user entered %f for N",N);
#endif
	float b=0;
	error_t res= entervalueabovewitherrorcode(0.5, &b);
	printf("The user entered %f for b (%d)\n",b, (int)res);
	if(res!=err_ok)
	{
		//Todo: add error handling
	}

	return 0;
}
/*********************************************************************
 * Function Implementation
 * ******************************************************************/

/*
 * This Function will ask the user to enter a specific value
 * The value will be returned if it is above the provided min boundary
 * If not the, the user will be asked to reenter the value
 *
 * \para float min : [IN] the minimum boundary of the value
 * return the entered value from the user
 * */

float entervalueabove(float min)
{
	float uservalue = 0;
	do {
        printf("please enter the value above or equal to %f :",min);
        scanf("%f",&uservalue);
	} while (uservalue < min);
	return uservalue;
}

/*
 * This Function will ask the user to enter a specific value
 * The value will be checked for validity and in case it is in range, it will be returned.
 * If it is not range the user date container will not be modified
 *
 * \para float min : [IN] the minimum boundary of the value
 * \para  float * const pusevalue : [out] the user data
 * return errok if valid data was entered, error code in other cases
 * */
error_t entervalueabovewitherrorcode(float min, float * const pusevalue)
{
	error_t result = err_ok;
	float uservalue=0;
	printf("please enter a value above or equal to %f:", min);
	scanf("%f", &uservalue);

	if(uservalue<min)
	{
		//wrong data provided, puservaue not satisfied
		result=err_dummy_user;
	}

}
